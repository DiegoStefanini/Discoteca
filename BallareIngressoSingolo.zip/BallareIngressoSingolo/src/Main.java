import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Inserisci il numero di persone persone: ");
        int nPersone = input.nextInt();

        Disco discoteca = new Disco();
        for (int i = 0; i < nPersone; i++) {
            ThreadClass cosa = new ThreadClass(discoteca);
            Thread thread = new Thread(cosa);
            thread.start();
        }

        int personedentro;
        while (true) {
            try{
                personedentro = discoteca.quantepersone();
                System.out.println("Persone dentro: "+personedentro);
                Thread.sleep(1000);
            } catch (InterruptedException a) {}
        }

    }
}