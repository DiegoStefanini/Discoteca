import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Quanti gruppi da 2: ");
        int nPersone = input.nextInt();
        Disco discoteca = new Disco();
        for (int i = 0; i < nPersone; i++) {
            ThreadClass cosa = new ThreadClass(discoteca);
            Thread thread = new Thread(cosa);
            thread.start();
        }
        int personeDentro;
        while(true){
            try{
                Thread.sleep(2000);
                personeDentro = discoteca.quantepersone();
                System.out.println("persone dentro: "+personeDentro);
            } catch (InterruptedException a) { }
        }

    }
}