public class Disco {
    private int ptotali;

    public synchronized void Entra() {
        ptotali = ptotali+2;
    }

    public synchronized void Esci() {
        ptotali = ptotali-2;
    }

    public int quantepersone(){
        return ptotali;
    }


}

