import java.util.Random;

public class ThreadClass implements Runnable {
    private Disco discoteca;
    private int tempo;
    private int persone;
    public ThreadClass(Disco discoteca) {
        this.discoteca = discoteca;
    }
    public void run() {
        while (true) {
            try {
                Random rand = new Random();
                tempo = rand.nextInt(100);
                discoteca.Entra();
                Thread.sleep(tempo);
                discoteca.Esci();
                Thread.sleep(tempo);
            } catch (InterruptedException a) {}
        }
    }
}
